import * as React from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { ChevronDown, ChevronUp } from "lucide-react";

// Import icons
import { 
  Home, Users, Clock, MapPin, UserPlus, DollarSign, 
  Wallet, CheckSquare, BarChart2, Users as UsersIcon, 
  FileText, Calculator, ClipboardList, Settings, HelpCircle,
  CalendarClock, UserCheck, Plane, Briefcase, FileSpreadsheet,
  UserCog, BriefcaseBusiness, Award, Receipt, Coins,
  CheckCircle,
  ExternalLink
} from "lucide-react";


// Sidebar submenu component
const SidebarSubmenu = ({ 
  title, 
  icon: Icon, 
  children, 
  defaultOpen = false 
}) => {
  const [isOpen, setIsOpen] = React.useState(defaultOpen);

  return (
    <div className="flex flex-col">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center justify-between w-full px-4 py-3 text-sm font-medium text-gray-300 hover:bg-blue-900/30 hover:text-white rounded-lg"
      >
        <div className="flex items-center gap-3">
          <Icon className="h-4 w-4" />
          <span>{title}</span>
        </div>
        {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
      </button>

      {isOpen && (
        <div className="ml-6 mt-1 space-y-1">
          {children}
        </div>
      )}
    </div>
  );
};

// Sidebar item component
const SidebarItem = ({ href, icon: Icon, children, end = false }) => {
  const [location] = useLocation();
  const isActive = end ? location === href : location.startsWith(href);

  return (
    <Link href={href}>
      <a className={cn(
        "sidebar-item",
        isActive ? "sidebar-item-active" : "sidebar-item-inactive"
      )}>
        <Icon className="h-4 w-4" />
        <span>{children}</span>
      </a>
    </Link>
  );
};

// Sidebar submenu item component
const SidebarSubmenuItem = ({ href, icon: Icon, children }) => {
  const [location] = useLocation();
  const isActive = location === href;

  return (
    <Link href={href}>
      <a className={cn(
        "flex items-center gap-3 px-3 py-2 text-sm rounded-lg transition-colors",
        isActive ? "bg-blue-900/50 text-white" : "text-gray-300 hover:bg-blue-900/30 hover:text-white"
      )}>
        <Icon className="h-4 w-4" />
        <span>{children}</span>
      </a>
    </Link>
  );
};

// Main sidebar component
export function Sidebar() {
  const { data } = useQuery({ queryKey: ["/api/users/me"] });
  const isAdmin = data?.user?.role === "admin";

  return (
    <div className="hidden md:flex h-screen w-64 flex-col bg-[#1e3a8a] text-white">
      {/* Logo */}
      <div className="flex h-16 items-center border-b px-4">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <img src="/myabsensi-logo.svg" alt="MyAbsensi" className="h-8 w-8" />
          <span className="text-2xl font-bold text-primary">MyAbsensi</span>
        </Link>
      </div>

      {/* Sidebar content */}
      <div className="flex-1 overflow-auto py-2">
        <div className="space-y-1 px-2">
          {/* Beranda */}
          <SidebarItem href="/" icon={Home} end>
            Beranda
          </SidebarItem>

          {/* Karyawan */}
          <SidebarItem href="/employees" icon={Users}>
            Karyawan
          </SidebarItem>

          {/* Kehadiran */}
          <SidebarSubmenu title="Kehadiran" icon={Clock}>
            <SidebarSubmenuItem href="/attendance/approval" icon={CheckSquare}>
              Approval Presensi
            </SidebarSubmenuItem>
            <SidebarSubmenuItem href="/attendance/schedule" icon={CalendarClock}>
              Jadwal Kerja
            </SidebarSubmenuItem>
            <SidebarSubmenuItem href="/attendance" icon={UserCheck}>
              Presensi
            </SidebarSubmenuItem>
            <SidebarSubmenuItem href="/leaves" icon={Plane}>
              Izin Cuti
            </SidebarSubmenuItem>
            <SidebarSubmenuItem href="/client-visits" icon={Briefcase}>
              Kunjungan Klien
            </SidebarSubmenuItem>
          </SidebarSubmenu>

          {/* Pelacakan Lokasi */}
          <SidebarItem href="/location" icon={MapPin}>
            Pelacakan Lokasi
          </SidebarItem>

          {/* Rekrutmen */}
          <SidebarSubmenu title="Rekrutmen" icon={UserPlus}>
            <SidebarSubmenuItem href="/recruitment/profile" icon={FileSpreadsheet}>
              Profil
            </SidebarSubmenuItem>
            <SidebarSubmenuItem href="/recruitment/management" icon={UserCog}>
              Manajemen Rekrutmen
            </SidebarSubmenuItem>
            <SidebarSubmenuItem href="/recruitment/jobs" icon={BriefcaseBusiness}>
              Lowongan Pekerjaan
            </SidebarSubmenuItem>
            <SidebarSubmenuItem href="/recruitment/candidates" icon={Award}>
              Kandidat
            </SidebarSubmenuItem>
          </SidebarSubmenu>

          {/* Payroll */}
          <SidebarItem href="/payroll" icon={DollarSign}>
            Payroll
          </SidebarItem>

          {/* Keuangan */}
          <SidebarSubmenu title="Keuangan" icon={Wallet}>
            <SidebarSubmenuItem href="/finance/cash" icon={Receipt}>
              Kasbon
            </SidebarSubmenuItem>
            <SidebarSubmenuItem href="/finance/reimbursement" icon={Coins}>
              Reimburse
            </SidebarSubmenuItem>
          </SidebarSubmenu>

          {/* Approval */}
          <SidebarItem href="/approvals" icon={CheckSquare}>
            Approval
          </SidebarItem>

          {/* Timeline */}
          <SidebarItem href="/timeline" icon={BarChart2}>
            Timeline
          </SidebarItem>

          {/* Klien */}
          <SidebarItem href="/clients" icon={UsersIcon}>
            Klien
          </SidebarItem>

          {/* Laporan */}
          <SidebarItem href="/reports" icon={FileText}>
            Laporan
          </SidebarItem>

          {/* Akuntansi */}
          <SidebarItem href="/accounting" icon={Calculator}>
            Akuntansi
          </SidebarItem>

          {/* Tugas */}
          <SidebarItem href="/tasks" icon={ClipboardList}>
            Tugas
          </SidebarItem>

          {/* Settings */}
          <SidebarItem href="/settings" icon={Settings}>
            Settings
          </SidebarItem>

          {/* FAQ */}
          <SidebarItem href="/faq" icon={HelpCircle}>
            FAQ
          </SidebarItem>
        </div>
      </div>

      {/* User info */}
      {data?.user && (
        <div className="flex items-center gap-2 border-t border-blue-800 p-4">
          <div className="h-8 w-8 rounded-full bg-blue-700 flex items-center justify-center">
            {data.user.name.charAt(0)}
          </div>
          <div>
            <p className="text-sm font-medium">{data.user.name}</p>
            <p className="text-xs text-blue-200">{data.user.role === "admin" ? "Admin" : "Karyawan"}</p>
          </div>
        </div>
      )}
    </div>
  );
}

export function MobileNav() {
  const [open, setOpen] = React.useState(false);
  const [location] = useLocation();
  const isLoginPage = location === "/login";

  if (isLoginPage) return null;

  return (
    <div className="md:hidden">
      <button
        onClick={() => setOpen(!open)}
        className="fixed top-4 right-4 z-40 rounded-md bg-blue-600 p-2 text-white"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          {open ? (
            <>
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </>
          ) : (
            <>
              <line x1="4" y1="12" x2="20" y2="12" />
              <line x1="4" y1="6" x2="20" y2="6" />
              <line x1="4" y1="18" x2="20" y2="18" />
            </>
          )}
        </svg>
      </button>

      {open && (
        <div className="fixed inset-0 z-30 bg-black/80">
          <div className="fixed inset-y-0 left-0 z-40 w-3/4 max-w-xs bg-[#1e3a8a] p-4">
            <Sidebar />
          </div>
        </div>
      )}
    </div>
  );
}