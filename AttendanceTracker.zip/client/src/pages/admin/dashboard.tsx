import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { 
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer 
} from "recharts";
import { Users, Clock, CalendarDays, Settings2 } from "lucide-react";

export default function AdminDashboard() {
  const { data: attendance } = useQuery({
    queryKey: ["/api/attendance"],
  });

  const { data: leaves } = useQuery({
    queryKey: ["/api/leaves"],
  });

  // Prepare data for the attendance chart
  const chartData = [
    { name: 'Sen', hadir: 45, terlambat: 5, tidakHadir: 2 },
    { name: 'Sel', hadir: 42, terlambat: 7, tidakHadir: 3 },
    { name: 'Rab', hadir: 47, terlambat: 3, tidakHadir: 2 },
    { name: 'Kam', hadir: 44, terlambat: 4, tidakHadir: 4 },
    { name: 'Jum', hadir: 40, terlambat: 8, tidakHadir: 4 }
  ];

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Dashboard Admin</h1>
        <div className="flex gap-4">
          <Link href="/admin/employees">
            <Button variant="outline">
              <Users className="mr-2 h-4 w-4" />
              Kelola Karyawan
            </Button>
          </Link>
          <Link href="/admin/shifts">
            <Button variant="outline">
              <Clock className="mr-2 h-4 w-4" />
              Kelola Shift
            </Button>
          </Link>
          <Link href="/settings">
            <Button variant="outline">
              <Settings2 className="mr-2 h-4 w-4" />
              Pengaturan
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader>
            <CardTitle>Total Karyawan</CardTitle>
            <CardDescription>Karyawan aktif saat ini</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">52</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Hadir Hari Ini</CardTitle>
            <CardDescription>Total kehadiran</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">42</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Terlambat</CardTitle>
            <CardDescription>Karyawan terlambat hari ini</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-500">5</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Pengajuan Cuti</CardTitle>
            <CardDescription>Menunggu persetujuan</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-500">3</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Statistik Kehadiran</CardTitle>
          <CardDescription>Minggu ini</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="hadir" stackId="a" fill="hsl(var(--primary))" name="Hadir" />
                <Bar dataKey="terlambat" stackId="a" fill="hsl(var(--warning))" name="Terlambat" />
                <Bar dataKey="tidakHadir" stackId="a" fill="hsl(var(--destructive))" name="Tidak Hadir" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Kehadiran Terbaru</CardTitle>
            <CardDescription>Hari ini, {format(new Date(), "dd MMMM yyyy")}</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nama</TableHead>
                  <TableHead>Waktu</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {attendance?.records?.slice(0, 5).map((record: any) => (
                  <TableRow key={record.id}>
                    <TableCell className="font-medium">
                      {record.userName || "John Doe"}
                    </TableCell>
                    <TableCell>
                      {format(new Date(record.checkInTime), "HH:mm")}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={record.status === "present" ? "default" : "destructive"}
                      >
                        {record.status === "present" ? "Hadir" : "Terlambat"}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Pengajuan Cuti</CardTitle>
            <CardDescription>Menunggu persetujuan</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nama</TableHead>
                  <TableHead>Tanggal</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {leaves?.leaves
                  ?.filter((leave: any) => leave.status === "pending")
                  .slice(0, 5)
                  .map((leave: any) => (
                    <TableRow key={leave.id}>
                      <TableCell className="font-medium">
                        {leave.userName || "John Doe"}
                      </TableCell>
                      <TableCell>
                        {format(new Date(leave.startDate), "dd/MM/yyyy")}
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">Menunggu</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}